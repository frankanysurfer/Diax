# Diax

Pre 7/07/2020

Wordpress installeren

Basis configuratie

Dummy tekst invoeren


7/07/2020

Plugins installeren en configureren

Akismet Anti-Spam

Contact Form 7

Contact Form 7: Accessible Defaults

Cookie Notice

Duplicator

Honeypot for Contact Form 7

Klassieke editor

Polylang


9/07/2020

Polylang probleem opgelost.

Contact form styling

10/07/2020

Contact form

Partners

13/07/2020

CSS
